from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials
from fastapi import HTTPException

from pathoverse.config import get_settings
from pathoverse.api.security import verify_api_key
from pathoverse.api.routes.analysis import router as analysis_router
from pathoverse.api.routes.benchmarks import router as benchmarks_router
from pathoverse.api.routes.health import router as health_router
from pathoverse.api.routes.models import router as models_router
from pathoverse.api.routes.retrieval import router as retrieval_router
from pathoverse.api.routes.slides import router as slides_router

settings = get_settings()
logger = logging.getLogger("pathoverse.api")

PUBLIC_PATHS = {
    "/",
    "/api/health",
    "/api/health/live",
    "/api/health/ready",
    "/docs",
    "/redoc",
    "/openapi.json",
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(
        "Starting %s v%s [%s]",
        settings.app_name,
        settings.app_version,
        settings.environment,
    )
    logger.info("Project root: %s", settings.project_root)
    logger.info("Data root: %s", settings.data_root)
    yield
    logger.info("Shutting down PathoVerse API")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Multimodal foundation-model platform for whole-slide "
        "pathology analysis, evaluation, retrieval, and benchmarking."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_origin_regex=settings.cors_origin_regex or None,
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=settings.cors_method_list,
    allow_headers=settings.cors_header_list,
)


@app.middleware("http")
async def api_authentication_middleware(request: Request, call_next):
    """Protect API routes with a production Bearer API key."""
    path = request.url.path

    if path in PUBLIC_PATHS or (
        request.method == "GET"
        and (
            path.endswith("/image")
            or path.endswith("/thumbnail")
            or path.endswith("/tissue-mask")
            or path.endswith("/heatmap")
        )
    ):
        return await call_next(request)

    auth_header = request.headers.get("Authorization")
    credentials = None

    if auth_header:
        scheme, _, token = auth_header.partition(" ")
        credentials = HTTPAuthorizationCredentials(
            scheme=scheme,
            credentials=token,
        )

    try:
        verify_api_key(request=request, credentials=credentials)
    except HTTPException as exc:
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": (
                        "UNAUTHORIZED"
                        if exc.status_code == 401
                        else "AUTHENTICATION_ERROR"
                    ),
                    "message": str(exc.detail),
                }
            },
            headers=exc.headers or {},
        )
    except Exception:
        logger.exception("Unexpected authentication middleware error")
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": "INTERNAL_SERVER_ERROR",
                    "message": "Authentication middleware failed.",
                }
            },
        )

    return await call_next(request)


app.include_router(health_router, prefix="/api")
app.include_router(models_router, prefix="/api")
app.include_router(slides_router, prefix="/api")
app.include_router(analysis_router, prefix="/api")
app.include_router(retrieval_router, prefix="/api")
app.include_router(benchmarks_router, prefix="/api")


@app.get("/")
def root():
    return {
        "service": settings.app_name,
        "version": settings.app_version,
        "environment": settings.environment,
        "status": "running",
        "docs": "/docs",
    }
