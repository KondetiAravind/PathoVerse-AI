# PathoVerse AI — Zero-Cost Deployment

## Architecture

- GPU inference: existing IIT/shared GPU server, GPU 0 only
- API: FastAPI inside Docker
- Public API: Cloudflare Quick Tunnel for demo/testing
- Frontend: Next.js on Vercel Hobby
- Authentication: Bearer API key

Cloudflare Quick Tunnels are free but are intended for testing/development and use a random `trycloudflare.com` hostname. They have a 200 in-flight request limit and no SLA. For a stable production hostname, use a named Cloudflare Tunnel with a domain.

## Server

```bash
cd ~/sam/aravind/my_projects/PathoVerse_AI
export CUDA_VISIBLE_DEVICES=0
docker compose up -d --build
docker compose ps
```

Install `cloudflared` locally without sudo:

```bash
mkdir -p ~/bin
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o ~/bin/cloudflared
chmod +x ~/bin/cloudflared
~/bin/cloudflared --version
```

Start the demo tunnel:

```bash
~/bin/cloudflared tunnel --url http://127.0.0.1:8000
```

Keep this process running. Copy the generated HTTPS `trycloudflare.com` URL.

## API key

Generate a fresh key before public deployment:

```bash
openssl rand -hex 32
```

Put it in `.env.production` as `PATHOVERSE_API_KEY=...`. Do not commit `.env.production`.

## Vercel

Import the `frontend/` directory as the Vercel project.

Set:

```text
NEXT_PUBLIC_API_BASE_URL=https://YOUR-TRY-CLOUDFLARE-HOSTNAME
NEXT_PUBLIC_PATHOVERSE_API_KEY=YOUR_64_CHARACTER_KEY
```

The API key is visible in the browser because this demo frontend calls the API directly. Use a dedicated demo key and rotate it after the demo.

## Important

Do not run global Docker prune/cleanup commands on the shared server. Do not stop or remove containers/images belonging to other users.
